Tekkit Classic: Born Again - Public Compatibility Data v3
Minecraft 1.19.2 / Forge 43.5.2

Included:
- 36 original conditional override stubs for stale compatibility recipes.
- 189 original empty loot-table overrides for absent Steam 'n' Rails integrations.

Install:
  global_packs/required_data/

This public version does not redistribute recipe files from ARR mods.
