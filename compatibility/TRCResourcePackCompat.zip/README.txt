Tekkit ReClassic
Minecraft 1.19.2 / Forge 43.5.2

Included fixes:
- Night Lights invalid model-parent references.
- IC2C Extras MOX and enriched-uranium texture path aliases.
- Fluid Matter UU Matter fluid blockstate.
- IC2 Classic / Immersive Weathering rubber-leaves compatibility.

Install:
  global_packs/required_resources/


Licensing:
See CREDITS_AND_LICENSES.txt and THIRD_PARTY_LICENSES/.
