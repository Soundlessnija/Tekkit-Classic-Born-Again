

Included:
- 36 original conditional override stubs for stale compatibility recipes.
- 189 original empty loot-table overrides for absent Steam 'n' Rails integrations.

Install:
  global_packs/required_data/

This public version does not redistribute recipe files from ARR mods.
