Tekkit Classic: Born Again - Public Compatibility Resources v3
Minecraft 1.19.2 / Forge 43.5.2

Included fixes:
- Night Lights invalid model-parent references.
- IC2C Extras MOX and enriched-uranium texture path aliases.
- Fluid Matter UU Matter fluid blockstate.
- IC2 Classic / Immersive Weathering rubber-leaves compatibility.

Install:
  global_packs/required_resources/

This is the publication-safe resource pack. Use it instead of Resources v1/v2.

Licensing:
See CREDITS_AND_LICENSES.txt and THIRD_PARTY_LICENSES/.
